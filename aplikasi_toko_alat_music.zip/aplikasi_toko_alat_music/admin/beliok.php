<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body
	<center>
		<?php
		include "../koneksi.php";
			session_start();
			if (!isset($_SESSION['username'])) {
				# code...
				header('Location:../sign in.php');
			}
			echo "<center>";
			include 'menu_admin.php'; 
			echo"</center>";
			
			$key = isset($_GET['key']) ? $_GET['key'] : "-";
			$id_member = isset($_POST['id_member']) ? $_POST['id_member'] : "-";
			$nama_member = isset($_POST['nama_member']) ? $_POST['nama_member'] : "-";
			$alamat = isset($_POST['alamat']) ? $_POST['alamat'] : "-";
			$no_hp = isset($_POST['no_hp']) ? $_POST['no_hp'] : "-";
			
			$sql = "select stok from barang where id_alat = '$key';";
		
		$hasil = mysqli_query($con, $sql);
		while ($cetak = mysqli_fetch_array($hasil)){
			$stok = $cetak['stok'];
		}
		mysqli_free_result($hasil);
		
		$stok = $stok - 1;
		
		$sql = "update barang set stok ='$stok' where id_alat = '$key';";
		
		$hasil = mysqli_query($con, $sql);
		if (mysqli_errno($con)) {
					# code...
			printf("Query gagal : %s\n", mysqli_error($con));
			exit();
		}

		mysqli_free_result($hasil);
			
		$sql = "INSERT INTO member (id_member, nama_member, alamat, no_hp) VALUES ('$id_member', '$nama_member', '$alamat', '$no_hp');";
		
		$hasil = mysqli_query($con, $sql);
		if (mysqli_errno($con)) {
					# code...
			printf("Query gagal : %s\n", mysqli_error($con));
			exit();
		}
		
		mysqli_free_result($hasil);
		
		$sql = "select harga from barang where id_alat = '$key';";
		

		$hasil = mysqli_query($con, $sql);
		while ($cetak = mysqli_fetch_array($hasil)){
			$harga = $cetak['harga'];
		}
		mysqli_free_result($hasil);
		
		$tgl = date('Y-m-d');
		
		$sql = "insert into transaksi values('', '$id_member', '$harga', '$tgl', '$key');";
		
		mysqli_query($con, $sql);
		
		
		
		
		?>
		<?php
	error_reporting(0);
	$duajamlagi = time() + 2 * 3600;
	//batas wakto cookie 2 jam
	setcookie(KunjunganTerakhir, date("G:i - m/d/y"), $duajamlagi);
	?>
		<h2><center>Selamat Transaksi Berhasil!</center></h2>
         <center><a href ="daftar_alat.php"><button>Kembali</button></a></center>
         
         

</body>
</html>