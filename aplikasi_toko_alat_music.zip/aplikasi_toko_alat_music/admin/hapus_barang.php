<?php 
session_start();
if(!isset($_SESSION['username'])){
 header('Location: ../login.php');
}
include 'menu_admin.php';
?>
<h2>.:: KONFIRMASI HAPUS BUKU ::.</h2>
<form type="text" method="post" action="proses_hapus.php?id_alat=<?php echo $_GET['id_alat'];?>">
<?php
	include '../koneksi.php';
	$id=$_GET['id_alat'];
	$idalat = $_POST['id_alat'];
	$jenis_gambar=$_FILES['userfile']['type']; 
	$name=$_FILES['userfile']['name'];
	$sql = "SELECT * FROM barang, gambar, jenis_barang WHERE barang.id_alat=gambar.id_alat AND barang.id_jenis=jenis_barang.id_jenis AND barang.id_alat='$id';";
	
	$hasil = mysqli_query( $con, $sql);
	if(mysqli_errno($con)){
	printf("Query gagal: %s\n", mysqli_error($con));
	 exit();
	}
	$cetak = mysqli_fetch_array($hasil);
?>
<table border=1 width=500px>
	<tr>
		<td colspan='2'><center><img src='../gambar/<?php echo $cetak['nama_gambar']?>' width='250px' height='350px'/></center></td>
	 </tr>
	<tr>
			<td width="250px"> Nama Alat Musik </td>
			<td width="250px"> <?php echo $cetak['nama_alat']?> </td>
		</tr>
		<tr>
		<td>Jenis Alat Musik</td>
		<td>
<?php echo $cetak['nama_jenis']?>

		</td>
	</tr>
		<tr>
			<td> Merk Alat Musik </td>
			<td> <?php echo $cetak['merk_alat']?></td>
		</tr>
		<tr>
			<td> Stok Alat Musik </td>
			<td> <?php echo $cetak['stok']?></td>
		</tr>
		<tr>
			<td> Harga Alat Musik </td>
			<td> <?php echo $cetak['harga']?></td>
		</tr>
	 <tr>
		<td colspan="2"><center>APAKAH DATA BUKU INI AKAN DIHAPUS ?</center>
			<center><a href="proses_hapus.php?id_alat=<?php echo $_GET['id_alat'] ?>">YA</a> <a href=#>TIDAK<a/></center></td>
	 </tr>
</table>
<br>
<?php
	mysqli_free_result($sql);
	mysqli_close();
?>
</form>
<?php
error_reporting(0);
$duajamlagi = time() + 2 * 3600;
//batas wakto cookie 2 jam
setcookie(KunjunganTerakhir, date("G:i - m/d/y"), $duajamlagi);
?>
