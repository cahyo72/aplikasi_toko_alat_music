<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
<?php
	session_start();
	if(!isset($_SESSION['username'])){
 		header('Location: ../login.php');
	}
	include 'menu_admin.php';
?>
<h2>INPUT DATA BARANG</h2>
<form action="" enctype="multipart/form-data" method="post">
	<table border="0">
		
		<tr>
			<td> Nama Alat Musik </td>
			<td> <input type="text" name="nama_alat" maxlength="50" size="30"/> </td>
		</tr>
		<tr>
		<td>Jenis Alat Musik</td>
		<td>
			<select name="jenis">
				<option value="gitar">Gitar</option>
				<option value="bass">Bass</option>
				<option value="drum">Drum</option>
				<option value="keyboard">Keyboard</option>
			</select>
		</td>
	</tr>
		<tr>
			<td> Merk Alat Musik </td>
			<td> <input type="text" name="merk_alat" maxlength="30" size="30"/> </td>
		</tr>
		<tr>
			<td> Stok Alat Musik </td>
			<td> <input type="number" name="stok" maxlength="8" size="8"/> </td>
		</tr>
		<tr>
			<td> Harga Alat Musik </td>
			<td> <input type="number" name="harga" maxlength="10" size="10"/> </td>
		</tr>
		<tr>
			<td> Gambar Alat Musik </td>
			<td> 
				<input type="hidden" name="max_size" value="500000" />
				<input name="userfile" type="file" /> 
			</td>
		</tr>
	</table>
	<hr>
	<input type="submit" value="Simpan" name="Proses"/>
	<input type="reset" value="Reset" name="reset"/>
</form>
<?php
	if (isset($_POST['Proses'])) {
		# code...
		$nama = strtolower($_POST['nama_alat']);
		$merk = strtolower($_POST['merk_alat']);
		$jenis = strtolower($_POST['jenis']);
		$stok = ($_POST['stok']);
		$harga = ($_POST['harga']);

		$namafolder = '../gambar/';
		$jenis_gambar = $_FILES['userfile']['type'];
		$name = $_FILES['userfile']['name'];
		$proses = $_POST['Proses'];
		$dataValid = "YA";



		if (strlen(trim($nama)) == 0) {
			# code...
			echo "Nama Alat Musik belum diisi!<br>";
			$dataValid = "TIDAK";
		}

		if (strlen(trim($merk)) == 0) {
			# code...
			echo "Merk Alat Musik belum diisi!<br>";
			$dataValid = "TIDAK";
		}
		if (strlen(trim($jenis)) == 0) {
			# code...
			echo "Jenis Alat Musik belum diisi!<br>";
			$dataValid = "TIDAK";
		}

		if (strlen(trim($stok)) == 0) {
			# code...
			echo "Stok Alat Musik belum diisi!<br>";
			$dataValid = "TIDAK";
		}

		if (strlen(trim($harga)) == 0) {
			# code...
			echo "Harga Alat Musik belum diisi!<br>";
			$dataValid = "TIDAK";
		}

		if ($dataValid == "TIDAK") {
			# code...
			echo "Terjadi Kesalahan, Silahkan dicek lagi";
		}
		
		include '../koneksi.php';

		$get_empty = mysqli_query( $con , "SELECT * FROM barang" );
		$cek = mysqli_num_rows($get_empty);

		$jncode = "";
		if ($jenis == "gitar") {
			# code...
			$jncode = "GT";
			$kodejenis = "M01";
		}elseif ($jenis == "bass") {
			# code...
			$jncode = "BS";
			$kodejenis = "M02";
		}elseif ($jenis == "drum") {
			# code...
			$jncode = "DR";
			$kodejenis = "M03";
		}elseif ($jenis == "keyboard") {
			# code...
			$jncode = "KB";
			$kodejenis = "M04";
		}
		
		$kode = "";
		$nolcode = "";
		if (empty($cek)) {
			# code...
			$numcode = 1;
		}else{
			$numcode = $cek + 1;
		}

		if ($numcode < 10) {
			# code...
			$nolcode = "00";
		}elseif ($numcode < 100) {
			# code...
			$nolcode = "0";
		}else{
			$nolcode = "";
		}

		$numstring = (string)$numcode;

		$kode = $jncode.$nolcode.$numstring;



		if ($proses == "Simpan") {
			# code...
			$sql = "INSERT INTO barang (id_alat,id_jenis,nama_alat,merk_alat,stok,harga)
			values ('$kode','$kodejenis','$nama','$merk','$stok','$harga');";
		}

		mysqli_query($con,$sql);

		if (mysqli_errno($con)) {
		 	# code...
		 	printf("Gagal Menambah data %s\n",mysqli_error($con));
		 	echo "<br>";
		 } else {
		 	echo "Data Berhasil disimpan";
		 	echo "<br>";

		 }

		 mysqli_free_result($sql);


		 
		 $sql = "INSERT INTO gambar (id_alat,nama_gambar)
		 values('$kode','$name');";

		 mysqli_query($con, $sql);	

		 if (mysqli_errno($con)) {
		 	# code...
		 	printf("Gagal menambah data: %s\n", mysqli_error($con));
			echo "<br/>";
		 }else{
		 	echo "Data Berhasil Disimpan!";
		 	echo "<br/>";
		 }
		
		mysqli_free_result($sql);


		 if($jenis_gambar=="image/jpg" || $jenis_gambar=="image/jpeg"){           
			$gambar = $namafolder .basename($_FILES['userfile']['name']);       
		if (move_uploaded_file($_FILES['userfile']['tmp_name'], 
		$gambar)) {
		echo "File telah berhasil diupload <br>";
				} 
				else{
		echo "File gagal diupload";
				}
			} 
			else{
				echo "Hanya Upload Gambar .jpg atau .jpeg";
			}
			mysqli_close();

	}

?>
<?php
error_reporting(0);
$duajamlagi = time() + 2 * 3600;
//batas wakto cookie 2 jam
setcookie(KunjunganTerakhir, date("G:i - m/d/y"), $duajamlagi);
?>
</center>
</body>
</html>