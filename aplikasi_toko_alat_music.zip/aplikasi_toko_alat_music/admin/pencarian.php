<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
	<?php
		session_start();
		if(!isset($_SESSION['username'])){
	 		header('Location: ../login.php');
		}
		include 'menu_admin.php';
	?>

	<h2>CARI BARANG</h2>
	<form action="" method="get">
		<table border="0">
			<tr>
				<td>Jenis Alat Musik </td>
				<td>
					<select name="jenis">
						<option value="gitar">Gitar</option>
						<option value="bass">Bass</option>
						<option value="drum">Drum</option>
						<option value="keyboard">Keyboard</option>
					</select>
				</td>
			</tr>
			<tr>
				<td>Nama Alat Musik </td>
				<td> <input type="text" name="nama_alat" maxlength="50" size="30"/> </td>
			</tr>
		</table>
		<hr>
		<input type="submit" value="cari" name="Proses"/>
		<input type="reset" value="Reset" name="reset"/>
	</form>

	<?php
	if (isset($_GET['Proses'])) {
		# code...
		$nama = strtolower($_GET['nama_alat']);
		$jenis = strtolower($_GET['jenis']);
		
		$proses = $_GET['Proses'];
		$dataValid = "YA";

		if (strlen(trim($nama)) == 0) {
			# code...
			echo "Nama Alat Musik belum diisi!<br>";
			$dataValid = "TIDAK";
		}

		
		if (strlen(trim($jenis)) == 0) {
			# code...
			echo "Jenis Alat Musik belum diisi!<br>";
			$dataValid = "TIDAK";
		}

		
		if ($dataValid == "TIDAK") {
			# code...
			echo "Terjadi Kesalahan, Silahkan dicek lagi";
		}
		
		include '../koneksi.php';

		$sql = "SELECT * FROM barang JOIN jenis_barang JOIN gambar 
		WHERE nama_alat LIKE '%$nama%' 
		AND nama_jenis = '$jenis';";

		$get_empty = mysqli_query( $con , $sql );
		if (mysqli_errno($con)) {
					# code...
			printf("Query gagal : %s\n", mysqli_error($con));
			exit();
		}
		$cek = mysqli_num_rows($get_empty);

		if (empty($cek)) {
			# code...
			echo "Data Tidak Ditemukan!";
			echo "<br>";
		}else{
			//header("Location: hasil_cari.php?nama = ".$nama." & jenis = ".$jenis);

			$sql = "SELECT * FROM barang JOIN jenis_barang JOIN gambar 
			WHERE nama_alat LIKE '%$nama%' 
			AND nama_jenis = '$jenis'
			AND barang.id_alat = gambar.id_alat
			AND jenis_barang.id_jenis = barang.id_jenis;";

			$hasil = mysqli_query( $con , $sql ); 

			?>
			<table border=1>
				<tr>
				<td width="100px"><center>Gambar</center></td>
				<td width="200px"><center>Kode Alat Musik</center></td>
				<td width="200px"><center>Nama Alat Musik</center></td>
				<td width="200px"><center>Jenis Alat Musik</center></td>
				<td width="200px"><center>Merk </center></td>
				<td width="200px"><center>Harga</center></td>
				<td width="200px"><center>Stok</center></td>
				<td width="200px"><center>Action</center></td>	
			</tr>
			<?php 
			while ($cetak = mysqli_fetch_array($hasil)) {
			 ?>
			 <tr>
				<td><center><img src="../gambar/<?php echo $cetak['nama_gambar']?>" width="75px" height="75px"/></center></td>
				<td><center><?php echo $cetak['id_alat']?></center></td>
				<td><center><?php echo $cetak['nama_alat']?></center></td>
				<td><center><?php echo $cetak['nama_jenis']?></center></td>
				<td><center><?php echo $cetak['merk_alat'] ?></center></td>
				<td><center><?php echo "Rp ".$cetak['harga'].",-" ?></center></td>
				<td><center><?php echo $cetak['stok'] ?></center></td>
				<td><center>|<a href="edit_barang.php">Edit</a> |<a href="hapus_barang.php">Delete</a> |</center></td>
			</tr>

			 <?php 
			 } 
		}

	mysqli_free_result($sql);
	mysqli_close();

	}

	?>
	<?php
	error_reporting(0);
	$duajamlagi = time() + 2 * 3600;
	//batas wakto cookie 2 jam
	setcookie(KunjunganTerakhir, date("G:i - m/d/y"), $duajamlagi);
	?>
</center>
</body>
</html>