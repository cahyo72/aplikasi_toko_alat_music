<form method="post" action="proses_edit.php?id_alat=<?php echo $_GET['id_alat'];?>" >
<?php
include "../koneksi.php";
		$idalat = $_POST['id_alat'];
		$nama = strtolower($_POST['nama_alat']);
		$merk = strtolower($_POST['merk_alat']);
		$jenis = strtolower($_POST['jenis']);
		$stok = ($_POST['stok']);
		$harga = ($_POST['harga']);

		$id 		= $_GET['id_alat'];
		$namafolder = '../gambar/';
		$jenis_gambar=$_FILES['userfile']['type']; 
		$name		= $_FILES['userfile']['name'];
		$proses = $_POST['proses'];

$sql = "UPDATE barang SET 	nama_alat		= '$nama',
							merk_alat		= '$merk',
							stok			= '$stok',
							harga			= '$harga'
		WHERE id_alat = '$id';";

mysqli_query($con, $sql);
		
		if(mysqli_errno($con)){
		printf("Gagal mengedit data barang: %s\n", mysqli_error($con));
		echo "<br/>";
		}
				
		else {
		echo "Data berhasil disimpan!";
		echo "<br/>";
		}
		mysqli_free_result($sql);
		
$sql = "UPDATE gambar SET 	nama_gambar	= '$name'
		WHERE id_alat='$id';";

mysqli_query($con, $sql);

		


		 if($jenis_gambar=="image/jpg" || $jenis_gambar=="image/jpeg"){           
			$gambar = $namafolder .basename($_FILES['userfile']['name']);       
		if (move_uploaded_file($_FILES['userfile']['tmp_name'], 
		$gambar)) {
		echo "File telah berhasil diupload <br>";
				} 
				else{
		echo "File gagal diupload";
				}
			} 
			else{
				echo "Hanya Upload Gambar .jpg atau .jpeg";
			}
			mysqli_close();
			
		mysqli_free_result($sql);
		mysqli_close();
?>
<input type='button' value='Kembali'
	onClick='self.history.back()'>
</form>
<?php
error_reporting(0);
$duajamlagi = time() + 2 * 3600;
//batas wakto cookie 2 jam
setcookie(KunjunganTerakhir, date("G:i - m/d/y"), $duajamlagi);
?>
