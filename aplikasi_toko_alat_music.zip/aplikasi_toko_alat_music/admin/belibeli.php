<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<center>
		<?php
			session_start();
			if (!isset($_SESSION['username'])) {
				# code...
				header('Location:../sign in.php');
			}
			include 'menu_admin.php';
		?>
		<h2>Alat Musikku</h2>
		<table width="500px" border="1px">
			<tr>
				<td width="250px"><center>Gambar</center></td>
				<td width="250px"><center>Nama Barang</center></td>
				<td width="250px"><center>Merk</center></td>
				<td width="250px"><center>Harga</center></td>
				<td width="250px"><center>Stok</center></td>
            	<td width="250px"><center></center></td>	
			</tr>
			<?php
				include '../koneksi.php';
				$sql = "SELECT * FROM barang JOIN gambar WHERE barang.id_alat = gambar.id_alat";
				$hasil = mysqli_query($con,$sql);
				if (mysqli_errno($con)) {
					# code...
					printf("Query gagal : %s\n", mysqli_error($con));
					exit();
				}

				while ($cetak = mysqli_fetch_array($hasil)) {
			?>
				
				<tr>
					<td><center><img src="../gambar/<?php echo $cetak['nama_gambar']?>" width="75px" height="75px"/></center></td>
					<td><center><?php echo $cetak['nama_alat']?></center></td>
					<td><center><?php echo $cetak['merk_alat'] ?></center></td>
					<td><center><?php echo "Rp ".$cetak['harga'].",-" ?></center></td>
					<td><center><?php echo $cetak['stok'] ?></center></td>
                    <td><center><a href ="beli.php ? key=<?php echo $cetak['id_alat'];?>"><button>Beli</button></a></center>
				</tr>	
			<?php
				}
			?>
		</table>
		<?php
	error_reporting(0);
	$duajamlagi = time() + 2 * 3600;
	//batas wakto cookie 2 jam
	setcookie(KunjunganTerakhir, date("G:i - m/d/y"), $duajamlagi);
	?>
	</center>
</body>
</html>