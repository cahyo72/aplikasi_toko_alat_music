<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<center>
		<?php
			session_start();
			if (!isset($_SESSION['username'])) {
				# code...
				header('Location:../sign in.php');
			}
			include 'menu_admin.php';
			
			$key = isset($_GET['key']) ? $_GET['key'] : "-";
		
		?>
        
        <form method="post" action="beliok.php ? key=<?php echo $key?>">
        	<table>
            <tr>
            	<td colspan=2><b><big><big>DATA PEMBELI</big></big></b></td>
                
                <tr><td><br/></td></tr>
             <tr>
            <td><b>ID Barang</b></td>>
            <td><input type="text" value=<?php echo $key ?> maxlength="5" size="5" required>
            </td>
            </tr>
                
            <tr>
            <td><b>ID Member</b></td>>
            <td><input type="text" name="id_member" maxlength="5" size="5" required>
            </td>
            </tr>
            
            <tr>
            <td><b>Nama Member</b></td>>
            <td><input type="text" name="nama_member" maxlength="60" size="60" required>
            </td>
            </tr>
            
            <tr>
            <td><b>Alamat</b></td>>
            <td><input type="text" name="alamat" maxlength="60" size="60" required>
            </td>
            </tr>
            
            <tr>
            <td><b>Nomor HP</b></td>>
            <td><input type="text" name="no_hp" maxlength="15" size="15" required>
            </td>
            </tr>
            
            <tr>
            <td><input type="submit" value="simpan"></td>
            </tr>
            
            </table>
            <?php
    error_reporting(0);
    $duajamlagi = time() + 2 * 3600;
    //batas wakto cookie 2 jam
    setcookie(KunjunganTerakhir, date("G:i - m/d/y"), $duajamlagi);
    ?>
        
</body>
</html>