<html>
|<a href="daftar_alat.php">HOME</a> | 
<a href="belibeli.php">TRANSAKSI</a> | 
<a href="input_alat.php">INPUT BARANG</a> |
<a href="pencarian.php">CARI BARANG</a> | 
<a href="../logout.php">KELUAR</a> | 
</html>