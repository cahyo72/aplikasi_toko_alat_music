<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
	<?php
		session_start();
		if(!isset($_SESSION['username'])){
	 		header('Location: ../login.php');
		}
		include 'menu_admin.php';
			$nama = $_GET['nama'];
			$jenis = $_GET['jenis'];
			echo $nama;
			echo $jenis;
	?>

	<h2>Hasil Pencarian</h2>
	<hr>
	<form action="" method="get">
		<?php 
		include '../koneksi.php';

			$sql = "SELECT * FROM barang JOIN jenis_barang JOIN gambar 
			WHERE nama_alat LIKE '%$nama%' 
			AND nama_jenis = '$jenis'
			AND barang.id_alat = gambar.id_alat
			AND jenis_barang.id_jenis = barang.id_jenis;";

			$hasil = mysqli_query( $con , $sql ); 

			while($cetak = mysqli_fetch_array($hasil)){
			?>
			<table border=1 width=400px>
				<tr>
				<td><center>Gambar</center></td>
				<td><center>Kode Alat Musik</center></td>
				<td><center>Nama Alat Musik</center></td>
				<td><center>Jenis Alat Musik</center></td>
				<td><center>Merk </center></td>
				<td><center>Harga</center></td>
				<td><center>Stok</center></td>
				<td><center>Action</center></td>	
			</tr>
			<?php 
				while ($cetak = mysqli_fetch_array($hasil)) {
			 ?>
			 <tr>
				<td><center><img src="../gambar/<?php echo $cetak['nama_gambar']?>" width="150px" height="150px"/></center></td>
				<td><center><?php echo $cetak['id_alat']?></center></td>
				<td><center><?php echo $cetak['nama_alat']?></center></td>
				<td><center><?php echo $cetak['nama_jenis']?></center></td>
				<td><center><?php echo $cetak['merk_alat'] ?></center></td>
				<td><center><?php echo "Rp ".$cetak['harga'].",-" ?></center></td>
				<td><center><?php echo $cetak['stok'] ?></center></td>
				<td><center>|<a href="edit_barang.php">Edit</a> |<a href="hapus_barang.php">Delete</a> |</center></td>
			</tr>

			 <?php 
			 } 
			 ?>
			</table>
			</form>
			<?php
				mysqli_free_result($sql);
				mysqli_close();
			}


		?>
		<?php
	error_reporting(0);
	$duajamlagi = time() + 2 * 3600;
	//batas wakto cookie 2 jam
	setcookie(KunjunganTerakhir, date("G:i - m/d/y"), $duajamlagi);
	?>
	</form>
</center>
</body>
</html>