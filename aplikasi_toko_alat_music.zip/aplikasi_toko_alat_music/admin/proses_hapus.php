<form type="text" method="post" action="proses_hapus.php?id_alat=<?php echo $_GET['id_alat'] ?>" >
<?php
	include '../koneksi.php';
	$id = $_GET['id_alat'];
	$sql = "DELETE FROM barang WHERE id_alat='$id';";
	$hasil = mysqli_query($con, $sql);
	
	if($hasil){
	echo "Data barang berhasil dihapus!";
	echo "<br/>";
	}
	else {
	echo "Data barang gagal dihapus!";
	}
	mysqli_free_result($sql);
	mysqli_close();
?>
<input type='button' value='Home'
	onClick='daftar_alat.php'>
</form>
