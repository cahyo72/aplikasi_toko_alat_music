<?php
session_start();
if(!isset($_SESSION['username'])){
 header('Location: ../login.php');
}
include 'menu_admin.php';
?>
<h1>.::EDIT BUKU::.</h1>
<hr>
<form enctype="multipart/form-data" action="proses_edit.php?id_alat=<?php echo $_GET['id_alat'];?>" method="post">
<?php
	include '../koneksi.php';
	$id = $_GET['id_alat'];

	$sql = "SELECT * FROM barang JOIN gambar on barang.id_alat = gambar.id_alat JOIN jenis_barang ON barang.id_jenis = jenis_barang.id_jenis WHERE barang.id_alat='$id';";
	
	
	$hasil = mysqli_query( $con, $sql);
	
	//sampai sini
	if(mysqli_errno($con)){
	printf("Query gagal: %s\n", mysqli_error($con));
	 exit();
	}
	$data = mysqli_fetch_array($hasil);
?>

<table border="0">
	<h2>EDIT DATA BARANG</h2>
<form action="" enctype="multipart/form-data" method="post">
	<table border="0">
		
		<tr>
			<td> Nama Alat Musik </td>
			<td> <input type="text" name="nama_alat" maxlength="50" size="30"  value="<?php echo $data['nama_alat']?>"/> </td>
		</tr>
		<tr>
		<td>Jenis Alat Musik</td>
		<td>
        <input type="text" name="nama_jenis" maxlength="50" size="30"  value="<?php echo $data['nama_jenis']?>"/> 

		</td>
	</tr>
		<tr>
			<td> Merk Alat Musik </td>
			<td> <input type="text" name="merk_alat" maxlength="30" size="30" value="<?php echo $data['merk_alat']?>" /> </td>
		</tr>
		<tr>
			<td> Stok Alat Musik </td>
			<td> <input type="number" name="stok" maxlength="8" size="8" value="<?php echo $data['stok']?>"/> </td>
		</tr>
		<tr>
			<td> Harga Alat Musik </td>
			<td> <input type="number" name="harga" maxlength="10" size="10" value="<?php echo $data['harga']?>"/> </td>
		</tr>
		<tr>
			<td> Gambar Alat Musik </td>
			<td> 
				<input type="hidden" name="max_size" value="500000" />
				<input name="userfile" type="file" /> 
                <br/>
		<img src='../gambar/<?php  echo $data['nama_gambar']?>' width='100px' height='150px'/>
			</td>
		</tr>
	</table>
<hr>
<input type = "submit" value="Simpan" name="proses"/>
<input type = "reset" value="Reset" name="reset"/>
</form>
<?php
error_reporting(0);
$duajamlagi = time() + 2 * 3600;
//batas wakto cookie 2 jam
setcookie(KunjunganTerakhir, date("G:i - m/d/y"), $duajamlagi);
?>