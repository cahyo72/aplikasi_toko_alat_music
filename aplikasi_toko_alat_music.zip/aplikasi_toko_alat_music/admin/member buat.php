<?php
	include 'koneksi.php';
	
	$id = "kapsul";
	$pass = "member";
	$nama = "Kristian Hendro S";
	$alamat = "Jalan...";
	$no_hp = "081";
	$pengguna = 3;
	$hasPass = md5($pass);

	$sql = "INSERT INTO member (id_member, password, nama_member, alamat, no_hp, pengguna)
	values ('$id','$hasPass','$nama','$alamat','$no_hp,'$pengguna);";

	$hasil = mysqli_query($con,$sql);

	if (!hasil) {
		# code...
		printf("Gagal mengisi tabel customer = %s\n",
			mysqli_error($con));
		exit();
	}
	mysqli_free_result($sql);

	$nama = "ibrohim";
	$pass = "admin";
	$pengguna = 2;
	$hasPass = md5($pass);

	$sql = "INSERT INTO admin (nama_admin, password, pengguna)
	values ('$nama','$hasPass',$pengguna);";

	$hasil = mysqli_query($con,$sql);

	if (!hasil) {
		# code...
		printf("Gagal mengisi tabel admin = %s\n",
			mysqli_error($con));
		exit();
	}
	

?>