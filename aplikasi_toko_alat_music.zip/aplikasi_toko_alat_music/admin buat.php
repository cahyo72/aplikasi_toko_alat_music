<?php
	include 'koneksi.php';

	$nama = "ibrohim";
	$pass = "admin";
	$pengguna = 2;
	$hasPass = md5($pass);

	$sql = "INSERT INTO admin (nama_admin, password, pengguna)
	values ('$nama','$hasPass',$pengguna);";

	$hasil = mysqli_query($con,$sql);

	if (!hasil) {
		# code...
		printf("Gagal mengisi tabel admin = %s\n",
			mysqli_error($con));
		exit();
	}
	
	$nama = "krisna";
	$pass = "owner";
	$pengguna = 1;
	$hasPass = md5($pass);

	$sql = "INSERT INTO admin (nama_admin, password, pengguna)
	values ('$nama','$hasPass',$pengguna);";

	$hasil = mysqli_query($con,$sql);

	if (!hasil) {
		# code...
		printf("Gagal mengisi tabel admin = %s\n",
			mysqli_error($con));
		exit();
	}
	mysqli_free_result($sql);


?>