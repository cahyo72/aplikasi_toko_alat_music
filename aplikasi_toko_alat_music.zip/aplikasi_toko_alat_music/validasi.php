<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<style type="text/css">
	body{
		background-color: green;
		color: black;
	}
</style>
<body>
<center>
	<?php
		session_start();
		$username = strtolower($_POST['user']);
		$password = strtolower($_POST['pass']);
		include 'koneksi.php';

		if (empty($username)||empty($password)) {
			# code...
			echo "<h2>Username atau Password Tidak Boleh kosong</h2>";
			include 'sign in.php';	
		}else{
			$sql = "SELECT * FROM admin WHERE nama_admin = '$username'";
			$hasil = mysqli_query($con,$sql);
			$hitung = mysqli_num_rows($hasil);
			$data = mysqli_fetch_array($hasil);
			if ($hitung == 0) {
				# code...
				echo "<h2>Maaf Username Tidak Ditemukan</h2>";
				include 'sign in.php';
				
			}else if (md5($password) != $data['password']) {
				# code...
				echo "<h2>Maaf Password yang anda masukkan Salah</h2>";
				include 'sign in.php';
				}else{
					$_SESSION['username'] = $username;
					if ($data['pengguna'] == 1) {
						# code...
						echo "Anda Masuk Sebagai Owner";
					}else if ($data['pengguna'] == 2) {
						# code...
						header('Location: admin/daftar_alat.php');
				}
			}
		}

		mysqli_free_result($hasil);
	?>

</center>
</body>
</html>