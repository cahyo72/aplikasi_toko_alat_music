<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php 
	session_start();
	if(!isset($_SESSION['username'])){
	 header('Location: ../login.php');
	}
	include 'menu_admin.php';
	?>
	<h1>Pencarian Alat Musik</h1>
	<hr>
	<form action="../hasil_cari_buku.php" method="post">
	<table border='0'>
		<tr>
			<td>Nama Alat Musik</td>
			<td><input type="text" name="judul" maxlength="50"
			size="40"/></td>
		</tr>
		
		<tr>
		<td></td>
		<td>
			<input type="radio" name="pengguna" value="admin" checked="checked">Admin<br>
			<input type="radio" name="pengguna" value="mahasiswa">Mahasiswa
		</td>
	</tr>
	</table>
	<hr>
	<input type = "submit" value="CARI" name="proses"/>
	</form>

	<?php
		if (isset($_POST['proses'])){
			$judul = strtolower($_POST['judul']);
			$penerbit = strtolower($_POST['penerbit']);
			
			if (strlen(trim($judul)) == 0) {
			echo "Judul buku harus diisi! <br/>";
			$dataValid="TIDAK";
			}
			
			if (strlen(trim($pengarang)) == 0) {
			echo "Pengarang buku harus diisi! <br/>";
			$dataValid="TIDAK";
			}
			
			if($dataValid == "TIDAK"){
			echo "Masih ada kesalahan, silahkan perbaiki! <br/>";
			}
			
			include 'koneksi.php';
			if ($proses == "Simpan")
			{
			$sql = "SELECT * FROM buku ORDER BY idbuku";
			}
			mysqli_query($con, $sql);
			
			if(mysqli_errno($con)){
			printf("Gagal menampilkan data: %s\n", mysqli_error($con));
			echo "<br/>";
			}
					
			else {
			echo "Data berhasil disimpan!";
			echo "<br/>";
			}
			mysqli_free_result($sql);
			mysqli_close();
		}
	?>
	<?php
	error_reporting(0);
	$duajamlagi = time() + 2 * 3600;
	//batas wakto cookie 2 jam
	setcookie(KunjunganTerakhir, date("G:i - m/d/y"), $duajamlagi);
	?>
</body>
</html>