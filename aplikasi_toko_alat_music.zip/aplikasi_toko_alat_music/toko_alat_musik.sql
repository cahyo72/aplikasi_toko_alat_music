-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 29, 2015 at 12:54 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `toko_alat_musik`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `nama_admin` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `pengguna` int(1) NOT NULL,
  PRIMARY KEY (`nama_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`nama_admin`, `password`, `pengguna`) VALUES
('ibrohim', '21232f297a57a5a743894a0e4a801fc3', 2),
('krisna', '72122ce96bfec66e2396d2e25225d70a', 1);

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `id_alat` varchar(5) NOT NULL,
  `id_jenis` varchar(5) NOT NULL,
  `nama_alat` varchar(60) NOT NULL,
  `merk_alat` varchar(30) DEFAULT NULL,
  `stok` int(3) DEFAULT NULL,
  `harga` int(10) DEFAULT NULL,
  PRIMARY KEY (`id_alat`),
  KEY `id_jenis` (`id_jenis`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_alat`, `id_jenis`, `nama_alat`, `merk_alat`, `stok`, `harga`) VALUES
('BS002', 'M02', 'bass', 'sonar', 9, 500000),
('GT001', 'M01', 'gt ini', 'yamaha', 3, 700000);

-- --------------------------------------------------------

--
-- Table structure for table `detail_transaksi`
--

CREATE TABLE IF NOT EXISTS `detail_transaksi` (
  `id_transaksi` int(5) NOT NULL,
  `id_alat` varchar(5) NOT NULL,
  `jumlah` int(5) NOT NULL,
  `harga` int(10) NOT NULL,
  KEY `id_transaksi` (`id_transaksi`),
  KEY `id_alat` (`id_alat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gambar`
--

CREATE TABLE IF NOT EXISTS `gambar` (
  `id_alat` varchar(5) NOT NULL,
  `nama_gambar` varchar(60) NOT NULL,
  KEY `id_alat` (`id_alat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gambar`
--

INSERT INTO `gambar` (`id_alat`, `nama_gambar`) VALUES
('GT001', '0938417620X310.jpg'),
('BS002', 'a2e1a56ea638d4cab9dab83a0570d808.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_barang`
--

CREATE TABLE IF NOT EXISTS `jenis_barang` (
  `id_jenis` varchar(5) NOT NULL,
  `nama_jenis` varchar(30) NOT NULL,
  PRIMARY KEY (`id_jenis`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_barang`
--

INSERT INTO `jenis_barang` (`id_jenis`, `nama_jenis`) VALUES
('M01', 'gitar'),
('M02', 'bass'),
('M03', 'drum'),
('M04', 'keyboard');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `id_member` varchar(5) NOT NULL,
  `nama_member` varchar(60) NOT NULL,
  `alamat` varchar(60) DEFAULT NULL,
  `no_hp` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_member`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id_member`, `nama_member`, `alamat`, `no_hp`) VALUES
('1231', 'lingga', 'magetan', '0987655'),
('3112', 'ilham', 'lingga', '0987655'),
('55566', 'krisna', 'solo', '097654345678'),
('qwert', 'asdfgh', 'qwqwqwqw', '121212121312');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE IF NOT EXISTS `transaksi` (
  `id_transaksi` int(5) NOT NULL AUTO_INCREMENT,
  `id_member` varchar(5) NOT NULL,
  `total_harga` int(10) NOT NULL,
  `tanggal` date NOT NULL,
  `id_alat` varchar(5) NOT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `id_member` (`id_member`),
  KEY `id_alat` (`id_alat`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_member`, `total_harga`, `tanggal`, `id_alat`) VALUES
(1, '1231', 700000, '0000-00-00', 'GT001'),
(2, '55566', 700000, '0000-00-00', 'GT001'),
(3, '3112', 700000, '2015-12-28', 'GT001');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`id_jenis`) REFERENCES `jenis_barang` (`id_jenis`);

--
-- Constraints for table `gambar`
--
ALTER TABLE `gambar`
  ADD CONSTRAINT `gambar_ibfk_1` FOREIGN KEY (`id_alat`) REFERENCES `barang` (`id_alat`);

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_member`) REFERENCES `member` (`id_member`),
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`id_alat`) REFERENCES `barang` (`id_alat`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
