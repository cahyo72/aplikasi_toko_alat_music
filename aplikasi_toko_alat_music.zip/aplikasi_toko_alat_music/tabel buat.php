<?php
	include 'koneksi.php';

	#tabel jenis barang
	$sql = "CREATE TABLE IF NOT EXISTS jenis_barang (
		id_jenis varchar(5) not null,
		nama_jenis varchar (30) not null,
		PRIMARY KEY (id_jenis));";

	mysqli_query($con,$sql);
	if (mysqli_errno($con)) {
		# code...
		printf("Gagal Membuat tabel jenis_barang : %s\n", mysqli_error($con));
		exit();
	}

	mysqli_free_result($sql);
	#tabel barang
	$sql = "CREATE TABLE IF NOT EXISTS barang (
		id_alat varchar(5) not null,
		id_jenis varchar(5) not null,
		nama_alat varchar (60) not null,
		merk_alat varchar (30) null,
		stok int (3) ,
		harga int (10) ,
		PRIMARY KEY (id_alat),
		FOREIGN KEY (id_jenis) REFERENCES jenis_barang (id_jenis));";

	mysqli_query($con,$sql);
	if (mysqli_errno($con)) {
		# code...
		printf("Gagal Membuat tabel barang : %s\n", mysqli_error($con));
		exit();
	} 

	mysqli_free_result($sql);

	#tabel gambar
	$sql = "CREATE TABLE IF NOT EXISTS gambar (
		id_alat varchar(5) not null,
		nama_gambar varchar (60) not null,
		FOREIGN KEY (id_alat) REFERENCES barang (id_alat));";

	mysqli_query($con,$sql);
	if (mysqli_errno($con)) {
		# code...
		printf("Gagal Membuat tabel barang : %s\n", mysqli_error($con));
		exit();
	}

	mysqli_free_result($sql);



	#tabel member
	$sql = "CREATE TABLE IF NOT EXISTS member (
		id_member varchar(5) not null,
		nama_member varchar (60) not null,
		alamat varchar (60) null,
		no_hp varchar (15),
		PRIMARY KEY (id_member));";

	mysqli_query($con,$sql);
	if (mysqli_errno($con)) {
		# code...
		printf("Gagal Membuat tabel member : %s\n", mysqli_error($con));
		exit();
	}

	mysqli_free_result($sql);

	#tabel admin
	$sql = "CREATE TABLE IF NOT EXISTS admin (
		nama_admin varchar(50) not null,
		password varchar (60) not null,
		pengguna int (1) not null,
		PRIMARY KEY (nama_admin));";

	mysqli_query($con,$sql);
	if (mysqli_errno($con)) {
		# code...
		printf("Gagal Membuat tabel admin : %s\n", mysqli_error($con));
		exit();
	}

	mysqli_free_result($sql);


	#tabel Transaksi
	$sql = "CREATE TABLE IF NOT EXISTS transaksi (
		id_transaksi int(5) AUTO_INCREMENT,
		id_member varchar(5) not null,
		total_harga int (10) not null,
		tanggal date not null,
		PRIMARY KEY (id_transaksi),
		FOREIGN KEY (id_member) REFERENCES member (id_member));";

	mysqli_query($con,$sql);
	if (mysqli_errno($con)) {
		# code...
		printf("Gagal Membuat tabel transaksi : %s\n", mysqli_error($con));
		exit();
	}
	mysqli_free_result($sql);

	#tabel detail Transaksi
	$sql = "CREATE TABLE IF NOT EXISTS detail_transaksi (
		id_transaksi int(5) not null,
		id_alat varchar(5) not null,
		jumlah int (5) not null, 
		harga int (10) not null,
		FOREIGN KEY (id_transaksi) REFERENCES transaksi (id_transaksi),
		FOREIGN KEY (id_alat) REFERENCES barang (id_alat));";

	mysqli_query($con,$sql);
	if (mysqli_errno($con)) {
		# code...
		printf("Gagal Membuat tabel detail transaksi : %s\n", mysqli_error($con));
		exit();
	}

	mysqli_free_result($sql);
	

?>