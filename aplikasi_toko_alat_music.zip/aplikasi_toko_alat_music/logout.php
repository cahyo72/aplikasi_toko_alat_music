<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<style type="text/css">
	body{
		background-color: green;
		color: black;
	}
</style>
<body>
<center>
<?php
session_start();
session_destroy();
?>
Anda telah Logout. Kembali ke halaman <strong><a
href='sign in.php'>Login</a></strong>.
<br>
<?php
if(isset($_COOKIE['KunjunganTerakhir'])) {
$visit = $_COOKIE['KunjunganTerakhir'];
echo "Kunjungan Anda terakhir pada - ". $visit;
}
else
echo "Anda sudah lebih dari 2 jam tidak mengunjungi web ini";
?>
</center>
</body>
</html>