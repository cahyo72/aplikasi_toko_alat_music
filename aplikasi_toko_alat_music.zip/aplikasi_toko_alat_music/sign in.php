<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<style type="text/css">
	body{
		background-color: green;
		color: black;
	}
</style>
<body>

<?php
	session_start();
	if(isset($_SESSION['username'])){
			session_destroy();
	}
?>
<center>
<h2> SIGN IN </h2>
<form action='validasi.php' method='post'>
<table border='0'>
	<tr>
		<td> Username </td><td> Password </td>		
	</tr>
	<tr>
		<td> <input type="text" name="user" maxlength="50"
		size="30"/> </td>
		<td><input type="password" name="pass" maxlength="50"
		size="30"/> </td>
	
		<td colspan="2" align="center">
		<input type = "submit" value="Sign In"
		name="proses"/>
		<input type = "reset" value="Cancel"
		name="reset"/>
		</td>
	</tr>
	
	
</table>
</form>
</center>
</body>
</html>